<?php
class C6Radio_Token_Manager {
    
    private static function get_tokens_table() {
        global $wpdb;
        return $wpdb->prefix . 'c6radio_push_tokens';
    }

    private static function get_history_table() {
        global $wpdb;
        return $wpdb->prefix . 'c6radio_push_history';
    }

    public static function create_tables() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        $tokens_table = self::get_tokens_table();
        $history_table = self::get_history_table();

        $sql_tokens = "CREATE TABLE IF NOT EXISTS $tokens_table (
            id BIGINT(20) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            token VARCHAR(255) UNIQUE NOT NULL,
            platform ENUM('ios', 'android', 'web') NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            last_used DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX platform_idx (platform),
            INDEX created_at_idx (created_at)
        ) $charset_collate;";

        $sql_history = "CREATE TABLE IF NOT EXISTS $history_table (
            id BIGINT(20) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(255) NOT NULL,
            message TEXT NOT NULL,
            article_id BIGINT(20) UNSIGNED NULL,
            sent_count INT DEFAULT 0,
            sent_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            sent_by BIGINT(20) UNSIGNED NULL,
            INDEX article_id_idx (article_id),
            INDEX sent_at_idx (sent_at)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_tokens);
        dbDelta($sql_history);
    }

    public function save_token($token, $platform = 'web') {
        global $wpdb;
        $table = self::get_tokens_table();

        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $table WHERE token = %s",
            $token
        ));

        if ($existing) {
            return $wpdb->update(
                $table,
                array('last_used' => current_time('mysql')),
                array('token' => $token),
                array('%s'),
                array('%s')
            );
        } else {
            return $wpdb->insert(
                $table,
                array(
                    'token' => $token,
                    'platform' => $platform,
                    'created_at' => current_time('mysql'),
                    'last_used' => current_time('mysql'),
                ),
                array('%s', '%s', '%s', '%s')
            );
        }
    }

    public function delete_token($token) {
        global $wpdb;
        $table = self::get_tokens_table();
        return $wpdb->delete($table, array('token' => $token), array('%s'));
    }

    public function get_all_tokens() {
        global $wpdb;
        $table = self::get_tokens_table();
        return $wpdb->get_results("SELECT token, platform FROM $table", ARRAY_A);
    }

    public function get_tokens_by_platform($platform) {
        global $wpdb;
        $table = self::get_tokens_table();
        return $wpdb->get_results($wpdb->prepare("SELECT token FROM $table WHERE platform = %s", $platform), ARRAY_A);
    }

    public function count_tokens() {
        global $wpdb;
        $table = self::get_tokens_table();
        return array(
            'total' => (int)$wpdb->get_var("SELECT COUNT(*) FROM $table"),
            'ios' => (int)$wpdb->get_var("SELECT COUNT(*) FROM $table WHERE platform = 'ios'"),
            'android' => (int)$wpdb->get_var("SELECT COUNT(*) FROM $table WHERE platform = 'android'"),
            'web' => (int)$wpdb->get_var("SELECT COUNT(*) FROM $table WHERE platform = 'web'"),
        );
    }

    public function cleanup_invalid_tokens($invalid_tokens) {
        if (empty($invalid_tokens)) return 0;
        global $wpdb;
        $table = self::get_tokens_table();
        $placeholders = implode(',', array_fill(0, count($invalid_tokens), '%s'));
        return $wpdb->query($wpdb->prepare("DELETE FROM $table WHERE token IN ($placeholders)", $invalid_tokens));
    }

    public function save_history($title, $message, $article_id = null, $sent_count = 0) {
        global $wpdb;
        $table = self::get_history_table();
        return $wpdb->insert($table, array(
            'title' => $title,
            'message' => $message,
            'article_id' => $article_id,
            'sent_count' => $sent_count,
            'sent_at' => current_time('mysql'),
            'sent_by' => get_current_user_id(),
        ), array('%s', '%s', '%d', '%d', '%s', '%d'));
    }

    public function get_history($limit = 50) {
        global $wpdb;
        $table = self::get_history_table();
        return $wpdb->get_results($wpdb->prepare("SELECT * FROM $table ORDER BY sent_at DESC LIMIT %d", $limit), ARRAY_A);
    }

    public function delete_old_tokens($days = 90) {
        global $wpdb;
        $table = self::get_tokens_table();
        $date = date('Y-m-d H:i:s', strtotime("-$days days"));
        return $wpdb->query($wpdb->prepare("DELETE FROM $table WHERE last_used < %s", $date));
    }
}

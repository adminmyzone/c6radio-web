<?php
class C6Radio_Admin_UI {
    
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        add_action('admin_post_c6radio_send_manual_push', array($this, 'handle_manual_send'));
    }

    public function add_admin_menu() {
        add_menu_page('Notifications Push', 'Push Notifs', 'manage_options', 'c6radio-push', array($this, 'render_main_page'), 'dashicons-megaphone', 26);
        add_submenu_page('c6radio-push', 'Envoyer', 'Envoyer', 'manage_options', 'c6radio-push-send', array($this, 'render_send_page'));
        add_submenu_page('c6radio-push', 'Historique', 'Historique', 'manage_options', 'c6radio-push-history', array($this, 'render_history_page'));
        add_submenu_page('c6radio-push', 'Paramètres', 'Paramètres', 'manage_options', 'c6radio-push-settings', array($this, 'render_settings_page'));
        add_submenu_page('c6radio-push', 'Debug', '🐛 Debug', 'manage_options', 'c6radio-push-debug', array($this, 'render_debug_page'));
    }

    public function register_settings() {
        register_setting('c6radio_push_settings', 'c6radio_push_service_account');
        register_setting('c6radio_push_settings', 'c6radio_push_project_id');
        register_setting('c6radio_push_settings', 'c6radio_push_auto_send');
    }

    public function enqueue_admin_assets($hook) {
        if (strpos($hook, 'c6radio-push') === false) return;
        wp_enqueue_style('c6radio-push-admin', C6RADIO_PUSH_PLUGIN_URL . 'assets/admin.css', array(), C6RADIO_PUSH_VERSION);
    }

    public function render_main_page() {
        $token_manager = new C6Radio_Token_Manager();
        $stats = $token_manager->count_tokens();
        ?>
        <div class="wrap c6radio-push-wrap">
            <h1>📱 Notifications Push C6Radio <span style="color:#f48771;font-size:14px;">(DEBUG MODE)</span></h1>
            <div class="c6radio-stats-grid">
                <div class="c6radio-stat-card"><div class="stat-icon">📊</div><div class="stat-number"><?php echo $stats['total']; ?></div><div class="stat-label">Total</div></div>
                <div class="c6radio-stat-card"><div class="stat-icon">📱</div><div class="stat-number"><?php echo $stats['ios']; ?></div><div class="stat-label">iOS</div></div>
                <div class="c6radio-stat-card"><div class="stat-icon">🤖</div><div class="stat-number"><?php echo $stats['android']; ?></div><div class="stat-label">Android</div></div>
                <div class="c6radio-stat-card"><div class="stat-icon">🌐</div><div class="stat-number"><?php echo $stats['web']; ?></div><div class="stat-label">Web</div></div>
            </div>
            <div class="c6radio-actions">
                <a href="<?php echo admin_url('admin.php?page=c6radio-push-send'); ?>" class="button button-primary button-hero">🔔 Envoyer</a>
                <a href="<?php echo admin_url('admin.php?page=c6radio-push-debug'); ?>" class="button button-secondary button-hero">🐛 Voir les logs</a>
            </div>
        </div>
        <?php
    }

    public function render_send_page() {
        $recent_posts = get_posts(array('numberposts' => 20, 'post_status' => 'publish'));
        ?>
        <div class="wrap c6radio-push-wrap">
            <h1>🔔 Envoyer une notification</h1>
            <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" class="c6radio-form">
                <?php wp_nonce_field('c6radio_send_push', 'c6radio_push_nonce'); ?>
                <input type="hidden" name="action" value="c6radio_send_manual_push">
                <table class="form-table">
                    <tr><th><label for="push_title">Titre *</label></th><td><input type="text" id="push_title" name="push_title" class="regular-text" required maxlength="65"></td></tr>
                    <tr><th><label for="push_message">Message *</label></th><td><textarea id="push_message" name="push_message" class="large-text" rows="4" required maxlength="240"></textarea></td></tr>
                    <tr><th><label for="push_article">Article</label></th><td><select id="push_article" name="push_article" class="regular-text"><option value="">-- Aucun --</option><?php foreach ($recent_posts as $post) : ?><option value="<?php echo $post->ID; ?>"><?php echo esc_html($post->post_title); ?></option><?php endforeach; ?></select></td></tr>
                    <tr><th><label for="push_image">Image URL</label></th><td><input type="url" id="push_image" name="push_image" class="regular-text"></td></tr>
                </table>
                <p class="submit"><button type="submit" class="button button-primary button-large">🚀 Envoyer</button></p>
            </form>
        </div>
        <?php
    }

    public function handle_manual_send() {
        if (!current_user_can('manage_options')) wp_die('Accès interdit');
        check_admin_referer('c6radio_send_push', 'c6radio_push_nonce');

        $title = sanitize_text_field($_POST['push_title']);
        $message = sanitize_textarea_field($_POST['push_message']);
        $article_id = isset($_POST['push_article']) ? intval($_POST['push_article']) : null;
        $image_url = isset($_POST['push_image']) ? esc_url_raw($_POST['push_image']) : null;

        $data = array();
        if ($article_id) {
            $post = get_post($article_id);
            if ($post) {
                $data['articleSlug'] = $post->post_name;
                $data['articleId'] = (string)$article_id;
            }
        }

        $token_manager = new C6Radio_Token_Manager();
        $tokens = $token_manager->get_all_tokens();

        if (empty($tokens)) {
            wp_redirect(add_query_arg('error', 'no_tokens', wp_get_referer()));
            exit;
        }

        $fcm_sender = new C6Radio_FCM_Sender();
        $result = $fcm_sender->send_to_tokens($tokens, $title, $message, $data, $image_url);
        $token_manager->save_history($title, $message, $article_id, $result['sent']);

        wp_redirect(add_query_arg(array('success' => 1, 'sent' => $result['sent']), admin_url('admin.php?page=c6radio-push-debug')));
        exit;
    }

    public function render_history_page() {
        $token_manager = new C6Radio_Token_Manager();
        $history = $token_manager->get_history(100);
        if (isset($_GET['success'])) echo '<div class="notice notice-success"><p>✅ Envoyé à ' . intval($_GET['sent']) . ' appareils!</p></div>';
        ?>
        <div class="wrap c6radio-push-wrap">
            <h1>📜 Historique</h1>
            <table class="wp-list-table widefat fixed striped">
                <thead><tr><th>Date</th><th>Titre</th><th>Message</th><th>Envoyés</th></tr></thead>
                <tbody>
                    <?php if (empty($history)) : ?><tr><td colspan="4" style="text-align:center;padding:40px;">Aucune notification</td></tr><?php else : ?>
                        <?php foreach ($history as $item) : ?>
                            <tr><td><?php echo date('d/m/Y H:i', strtotime($item['sent_at'])); ?></td><td><strong><?php echo esc_html($item['title']); ?></strong></td><td><?php echo esc_html(substr($item['message'], 0, 60)); ?>...</td><td><?php echo $item['sent_count']; ?> 📱</td></tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    public function render_settings_page() {
        if (isset($_POST['submit'])) {
            check_admin_referer('c6radio_push_settings');
            update_option('c6radio_push_service_account', wp_unslash($_POST['service_account']));
            update_option('c6radio_push_project_id', sanitize_text_field($_POST['project_id']));
            update_option('c6radio_push_auto_send', isset($_POST['auto_send']) ? 1 : 0);
            echo '<div class="notice notice-success"><p>✅ Paramètres enregistrés</p></div>';
        }

        $service_account = get_option('c6radio_push_service_account', '');
        $project_id = get_option('c6radio_push_project_id', '');
        $auto_send = get_option('c6radio_push_auto_send', true);
        ?>
        <div class="wrap c6radio-push-wrap">
            <h1>⚙️ Paramètres</h1>
            <form method="post" class="c6radio-form">
                <?php wp_nonce_field('c6radio_push_settings'); ?>
                <table class="form-table">
                    <tr><th><label for="project_id">Project ID *</label></th><td><input type="text" id="project_id" name="project_id" value="<?php echo esc_attr($project_id); ?>" class="regular-text"></td></tr>
                    <tr><th><label for="service_account">Service Account JSON *</label></th><td><textarea id="service_account" name="service_account" class="large-text code" rows="10"><?php echo esc_textarea($service_account); ?></textarea></td></tr>
                    <tr><th><label for="auto_send">Envoi auto</label></th><td><label><input type="checkbox" id="auto_send" name="auto_send" value="1" <?php checked($auto_send, 1); ?>>Envoyer auto à chaque publication</label></td></tr>
                </table>
                <p class="submit"><button type="submit" name="submit" class="button button-primary">💾 Enregistrer</button></p>
            </form>
        </div>
        <?php
    }

    public function render_debug_page() {
        ?>
        <div class="wrap c6radio-push-wrap">
            <h1>🐛 Debug Logs</h1>
            <div style="background:#1e1e1e;color:#d4d4d4;padding:20px;border-radius:8px;font-family:monospace;font-size:13px;max-height:600px;overflow-y:auto;">
                <?php
                $logs = get_option('c6radio_push_debug_logs', array());
                if (empty($logs)) {
                    echo '<p style="color:#888;">Aucun log. Envoie une notification pour générer des logs.</p>';
                } else {
                    foreach ($logs as $log) {
                        $color = '#d4d4d4';
                        if (strpos($log, '✅') !== false) $color = '#4ec9b0';
                        if (strpos($log, '❌') !== false) $color = '#f48771';
                        if (strpos($log, '🚀') !== false) $color = '#dcdcaa';
                        if (strpos($log, '📤') !== false) $color = '#569cd6';
                        if (strpos($log, '📊') !== false) $color = '#c586c0';
                        echo '<div style="color:' . $color . ';margin-bottom:5px;">' . esc_html($log) . '</div>';
                    }
                }
                ?>
            </div>
            <p style="margin-top:20px;">
                <a href="?page=c6radio-push-debug&clear=1" class="button">🗑️ Vider</a>
                <a href="?page=c6radio-push-debug" class="button button-primary">🔄 Rafraîchir</a>
            </p>
        </div>
        <?php
        if (isset($_GET['clear'])) {
            delete_option('c6radio_push_debug_logs');
            echo '<script>location.href="?page=c6radio-push-debug";</script>';
        }
    }
}

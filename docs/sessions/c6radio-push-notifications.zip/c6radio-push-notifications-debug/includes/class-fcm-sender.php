<?php
/**
 * Class C6Radio_FCM_Sender (VERSION DEBUG)
 * Envoi de notifications via Firebase Cloud Messaging API v1 (OAuth 2.0)
 * Avec logs détaillés pour debugging
 */

class C6Radio_FCM_Sender {
    
    private function get_fcm_url() {
        $project_id = get_option('c6radio_push_project_id', '');
        return "https://fcm.googleapis.com/v1/projects/{$project_id}/messages:send";
    }

    private function get_service_account() {
        return get_option('c6radio_push_service_account', '');
    }

    private function get_access_token() {
        $service_account_json = $this->get_service_account();
        
        if (empty($service_account_json)) {
            $this->log_debug('❌ Service account JSON vide');
            return false;
        }

        $service_account = json_decode($service_account_json, true);
        
        if (!$service_account || !isset($service_account['private_key']) || !isset($service_account['client_email'])) {
            $this->log_debug('❌ Service account JSON invalide ou clés manquantes');
            return false;
        }

        $this->log_debug('✅ Service account chargé: ' . $service_account['client_email']);

        $now = time();
        $expiration = $now + 3600;

        $header = base64_encode(json_encode([
            'alg' => 'RS256',
            'typ' => 'JWT'
        ]));

        $claim_set = base64_encode(json_encode([
            'iss' => $service_account['client_email'],
            'scope' => 'https://www.googleapis.com/auth/firebase.messaging',
            'aud' => 'https://oauth2.googleapis.com/token',
            'iat' => $now,
            'exp' => $expiration
        ]));

        $signature_input = str_replace('=', '', $header) . '.' . str_replace('=', '', $claim_set);
        
        $private_key = openssl_pkey_get_private($service_account['private_key']);
        if (!$private_key) {
            $this->log_debug('❌ Erreur lecture clé privée');
            return false;
        }

        openssl_sign($signature_input, $signature, $private_key, OPENSSL_ALGO_SHA256);
        openssl_free_key($private_key);

        $jwt = $signature_input . '.' . str_replace('=', '', base64_encode($signature));

        $this->log_debug('✅ JWT généré, échange contre access token...');

        $ch = curl_init('https://oauth2.googleapis.com/token');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/x-www-form-urlencoded']);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
            'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
            'assertion' => $jwt
        ]));

        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($http_code !== 200) {
            $this->log_debug("❌ Erreur OAuth HTTP $http_code: $response");
            return false;
        }

        $token_data = json_decode($response, true);
        if (isset($token_data['access_token'])) {
            $this->log_debug('✅ Access token obtenu');
            return $token_data['access_token'];
        }
        
        $this->log_debug('❌ Access token non trouvé dans la réponse');
        return false;
    }

    public function send_to_tokens($tokens, $title, $body, $data = array(), $image_url = null) {
        $this->log_debug("🚀 Début envoi notification: '$title' à " . count($tokens) . " tokens");
        
        $access_token = $this->get_access_token();

        if (!$access_token) {
            $this->log_debug('❌ ÉCHEC: Impossible de générer access token');
            return array(
                'success' => false,
                'error' => 'Impossible de générer un access token OAuth',
                'sent' => 0,
            );
        }

        if (empty($tokens)) {
            $this->log_debug('❌ ÉCHEC: Aucun token fourni');
            return array(
                'success' => false,
                'error' => 'Aucun token fourni',
                'sent' => 0,
            );
        }

        $total_sent = 0;
        $total_failed = 0;
        $invalid_tokens = array();

        foreach ($tokens as $index => $token_data) {
            $token = is_array($token_data) ? $token_data['token'] : $token_data;
            
            $this->log_debug("📤 Envoi au token #" . ($index + 1) . ": " . substr($token, 0, 20) . "...");
            
            $result = $this->send_single($token, $title, $body, $data, $image_url, $access_token);
            
            if ($result['success']) {
                $total_sent++;
                $this->log_debug("✅ Token #" . ($index + 1) . " OK");
            } else {
                $total_failed++;
                $this->log_debug("❌ Token #" . ($index + 1) . " ÉCHEC: " . $result['error']);
                if ($result['invalid']) {
                    $invalid_tokens[] = $token;
                    $this->log_debug("🗑️ Token #" . ($index + 1) . " marqué comme invalide");
                }
            }
        }

        if (!empty($invalid_tokens)) {
            $token_manager = new C6Radio_Token_Manager();
            $cleaned = $token_manager->cleanup_invalid_tokens($invalid_tokens);
            $this->log_debug("🧹 $cleaned tokens invalides supprimés de la base");
        }

        $this->log_debug("📊 RÉSULTAT: $total_sent réussis, $total_failed échecs");

        return array(
            'success' => $total_sent > 0,
            'sent' => $total_sent,
            'failed' => $total_failed,
            'invalid_tokens_removed' => count($invalid_tokens),
        );
    }

    private function send_single($token, $title, $body, $data, $image_url, $access_token) {
        $fcm_url = $this->get_fcm_url();

        $notification = array(
            'title' => $title,
            'body' => $body,
        );

        if ($image_url) {
            $notification['image'] = $image_url;
        }

        $fcm_data = array();
        if (!empty($data)) {
            foreach ($data as $key => $value) {
                $fcm_data[$key] = is_string($value) ? $value : json_encode($value);
            }
        }

        $message = array(
            'token' => $token,
            'notification' => $notification,
            'android' => array(
                'priority' => 'high',
            ),
            'apns' => array(
                'headers' => array(
                    'apns-priority' => '10',
                ),
            ),
        );

        if (!empty($fcm_data)) {
            $message['data'] = $fcm_data;
        }

        $payload = array('message' => $message);

        $headers = array(
            'Authorization: Bearer ' . $access_token,
            'Content-Type: application/json',
        );

        $ch = curl_init($fcm_url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));

        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($http_code === 200) {
            return array('success' => true, 'invalid' => false, 'error' => '');
        }

        $error_data = json_decode($response, true);
        $is_invalid = false;
        $error_message = "HTTP $http_code";

        if (isset($error_data['error'])) {
            $error_message .= ": " . ($error_data['error']['message'] ?? 'Erreur inconnue');
            
            if (isset($error_data['error']['status'])) {
                $status = $error_data['error']['status'];
                if (in_array($status, array('NOT_FOUND', 'INVALID_ARGUMENT', 'UNREGISTERED'))) {
                    $is_invalid = true;
                }
            }
        }

        return array('success' => false, 'invalid' => $is_invalid, 'error' => $error_message);
    }

    private function log_debug($message) {
        // Stocker les logs dans une option temporaire
        $logs = get_option('c6radio_push_debug_logs', array());
        $logs[] = '[' . date('H:i:s') . '] ' . $message;
        
        // Garder seulement les 100 derniers logs
        if (count($logs) > 100) {
            $logs = array_slice($logs, -100);
        }
        
        update_option('c6radio_push_debug_logs', $logs);
    }

    public function send_test($token, $platform = 'web') {
        return $this->send_to_tokens(
            array(array('token' => $token, 'platform' => $platform)),
            'Test C6Radio',
            'Ceci est une notification de test',
            array('test' => true)
        );
    }
}

# 🔑 Configuration Firebase - API v1 (OAuth 2.0)

L'API Legacy FCM a été retirée par Google. Il faut maintenant utiliser **l'API v1 avec OAuth 2.0**.

---

## ÉTAPE 1 : Récupérer le Project ID

1. Va sur **https://console.firebase.google.com**
2. Sélectionne ton projet C6Radio
3. Clique sur **⚙️ (engrenage) > Paramètres du projet**
4. Note le **"ID du projet"** / **"Project ID"** (ex: `c6radio-12345`)

**👉 Tu auras besoin de cette valeur dans WordPress**

---

## ÉTAPE 2 : Générer une clé de service account

1. Toujours dans Firebase Console > **⚙️ Paramètres du projet**
2. Onglet **"Comptes de service"** / **"Service accounts"**
3. Clique sur **"Générer une nouvelle clé privée"** / **"Generate new private key"**
4. Une popup s'affiche : clique sur **"Générer la clé"**
5. Un fichier JSON est téléchargé (ex: `c6radio-12345-firebase-adminsdk-xxxxx.json`)

⚠️ **IMPORTANT** : Ce fichier contient des informations **TRÈS SECRÈTES**. Ne le partage JAMAIS publiquement !

---

## ÉTAPE 3 : Configurer le plugin WordPress

### 3.1 Ouvre le fichier JSON téléchargé

Il ressemble à ça :

```json
{
  "type": "service_account",
  "project_id": "c6radio-12345",
  "private_key_id": "abc123...",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBA...\n-----END PRIVATE KEY-----\n",
  "client_email": "firebase-adminsdk-xxxxx@c6radio-12345.iam.gserviceaccount.com",
  "client_id": "1234567890",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  ...
}
```

### 3.2 Va dans WordPress Admin

1. Menu **Push Notifs > Paramètres**
2. Remplis les champs :

**Project ID Firebase** :
```
c6radio-12345
```
_(remplace par ton vrai Project ID)_

**Service Account JSON** :
```json
{
  "type": "service_account",
  "project_id": "c6radio-12345",
  ...
}
```
_(colle TOUT le contenu du fichier JSON, tel quel)_

3. Coche **"Envoi automatique"**
4. Clique sur **💾 Enregistrer**

---

## ✅ Vérification

Si tout est bon, tu verras :
- ✅ Message "Paramètres enregistrés" en vert
- Pas d'erreur affichée

---

## 🧪 Test rapide (optionnel)

Pour tester immédiatement si ça fonctionne :

1. Va dans **Push Notifs > Envoyer**
2. Remplis :
   - Titre : `Test`
   - Message : `Ceci est un test`
3. Clique sur **Envoyer**

**Note** : Tu ne recevras la notification QUE si tu as déjà lancé l'app mobile et accepté les permissions. Sinon, c'est normal de voir "0 appareils enregistrés".

---

## ⚠️ Différences avec l'API Legacy

| Aspect | API Legacy (obsolète) | API v1 (actuelle) |
|--------|----------------------|-------------------|
| **Authentification** | Server Key simple | OAuth 2.0 (Service Account JSON) |
| **Endpoint** | `/fcm/send` | `/v1/projects/{id}/messages:send` |
| **Multicast** | Oui (1000 tokens/req) | Non (1 token/requête) |
| **Sécurité** | Faible | Forte |

Le plugin gère automatiquement :
- ✅ Génération du JWT (JSON Web Token)
- ✅ Échange OAuth pour obtenir un access token
- ✅ Envoi des notifications une par une
- ✅ Gestion des tokens invalides

---

## 🐛 En cas d'erreur

### "Impossible de générer un access token"
→ Vérifie que le JSON est complet et valide (pas de caractères manquants)

### "Error 403 Forbidden"
→ Vérifie que l'API "Firebase Cloud Messaging API" est activée :
1. Google Cloud Console > APIs & Services > Library
2. Cherche "Firebase Cloud Messaging API"
3. Clique dessus et active-la

### "Error 404 Project not found"
→ Vérifie que le Project ID est correct

---

**Prêt ?** Copie ton Project ID et ton JSON, puis configure WordPress ! 🚀

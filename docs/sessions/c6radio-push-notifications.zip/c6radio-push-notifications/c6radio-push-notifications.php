<?php
/**
 * Plugin Name: C6Radio Push Notifications
 * Plugin URI: https://c6media.fr
 * Description: Notifications PUSH via Firebase Cloud Messaging v1 (API OAuth 2.0). Envoi automatique + manuel.
 * Version: 2.0.0
 * Author: C6Radio
 * License: GPL v2 or later
 * Text Domain: c6radio-push
 */

if (!defined('ABSPATH')) exit;

define('C6RADIO_PUSH_VERSION', '2.0.0');
define('C6RADIO_PUSH_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('C6RADIO_PUSH_PLUGIN_URL', plugin_dir_url(__FILE__));

require_once C6RADIO_PUSH_PLUGIN_DIR . 'includes/class-token-manager.php';
require_once C6RADIO_PUSH_PLUGIN_DIR . 'includes/class-fcm-sender.php';
require_once C6RADIO_PUSH_PLUGIN_DIR . 'includes/class-admin-ui.php';

register_activation_hook(__FILE__, 'c6radio_push_activate');
function c6radio_push_activate() {
    C6Radio_Token_Manager::create_tables();
    flush_rewrite_rules();
}

register_deactivation_hook(__FILE__, 'c6radio_push_deactivate');
function c6radio_push_deactivate() {
    flush_rewrite_rules();
}

add_action('rest_api_init', function() {
    register_rest_route('c6radio/v1', '/register-token', array(
        'methods' => 'POST',
        'callback' => 'c6radio_register_token',
        'permission_callback' => '__return_true',
    ));

    register_rest_route('c6radio/v1', '/unregister-token', array(
        'methods' => 'POST',
        'callback' => 'c6radio_unregister_token',
        'permission_callback' => '__return_true',
    ));
});

function c6radio_register_token($request) {
    $params = $request->get_json_params();
    $token = isset($params['token']) ? sanitize_text_field($params['token']) : '';
    $platform = isset($params['platform']) ? sanitize_text_field($params['platform']) : 'web';

    if (empty($token)) {
        return new WP_Error('missing_token', 'Token manquant', array('status' => 400));
    }

    $token_manager = new C6Radio_Token_Manager();
    $result = $token_manager->save_token($token, $platform);

    if ($result) {
        return array(
            'success' => true,
            'message' => 'Token enregistré',
            'token' => $token,
            'platform' => $platform,
        );
    }

    return new WP_Error('save_failed', 'Erreur', array('status' => 500));
}

function c6radio_unregister_token($request) {
    $params = $request->get_json_params();
    $token = isset($params['token']) ? sanitize_text_field($params['token']) : '';

    if (empty($token)) {
        return new WP_Error('missing_token', 'Token manquant', array('status' => 400));
    }

    $token_manager = new C6Radio_Token_Manager();
    $result = $token_manager->delete_token($token);

    return $result ? array('success' => true) : new WP_Error('delete_failed', 'Erreur', array('status' => 500));
}

add_action('publish_post', 'c6radio_send_push_on_publish', 10, 2);
function c6radio_send_push_on_publish($post_id, $post) {
    if ($post->post_status !== 'publish') return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!get_option('c6radio_push_auto_send', true)) return;

    $title = 'Nouvel article C6Radio';
    $body = $post->post_title;
    $image_url = get_the_post_thumbnail_url($post_id, 'medium');
    $article_slug = $post->post_name;

    $token_manager = new C6Radio_Token_Manager();
    $tokens = $token_manager->get_all_tokens();

    if (empty($tokens)) return;

    $fcm_sender = new C6Radio_FCM_Sender();
    $result = $fcm_sender->send_to_tokens($tokens, $title, $body, array(
        'articleSlug' => $article_slug,
        'articleId' => (string)$post_id,
    ), $image_url);

    if ($result['success']) {
        $token_manager->save_history($title, $body, $post_id, $result['sent']);
    }
}

if (is_admin()) {
    new C6Radio_Admin_UI();
}
